export interface Institucion {
    id:          number;
    nombre:      string;
    descripcion: string;
    isDelete:    boolean;
    createdAt:   Date;
    updatedAt:   Date;
}