export interface Permiso {
    id:          number;
    Permiso:     string;
    Descripcion: null;
    isDelete:    boolean;
    createdAt:   Date;
    updatedAt:   Date;
}