import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-institucion',
  templateUrl: './update-institucion.component.html',
  styleUrls: ['./update-institucion.component.css']
})
export class UpdateInstitucionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
