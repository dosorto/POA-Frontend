import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-rol',
  templateUrl: './detail-rol.component.html',
  styleUrls: ['./detail-rol.component.css']
})
export class DetailRolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
