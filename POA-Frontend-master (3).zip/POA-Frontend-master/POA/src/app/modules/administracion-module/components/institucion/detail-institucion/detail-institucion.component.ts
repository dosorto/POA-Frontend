import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-institucion',
  templateUrl: './detail-institucion.component.html',
  styleUrls: ['./detail-institucion.component.css']
})
export class DetailInstitucionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
