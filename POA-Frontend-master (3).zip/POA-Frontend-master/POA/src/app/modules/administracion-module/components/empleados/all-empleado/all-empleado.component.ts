import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-empleado',
  templateUrl: './all-empleado.component.html',
  styleUrls: ['./all-empleado.component.css']
})
export class AllEmpleadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
