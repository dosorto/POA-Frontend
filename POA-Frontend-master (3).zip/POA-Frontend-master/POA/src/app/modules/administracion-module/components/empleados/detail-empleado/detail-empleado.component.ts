import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-empleado',
  templateUrl: './detail-empleado.component.html',
  styleUrls: ['./detail-empleado.component.css']
})
export class DetailEmpleadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
