import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-rol',
  templateUrl: './update-rol.component.html',
  styleUrls: ['./update-rol.component.css']
})
export class UpdateRolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
