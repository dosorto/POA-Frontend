import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-empleado',
  templateUrl: './update-empleado.component.html',
  styleUrls: ['./update-empleado.component.css']
})
export class UpdateEmpleadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
