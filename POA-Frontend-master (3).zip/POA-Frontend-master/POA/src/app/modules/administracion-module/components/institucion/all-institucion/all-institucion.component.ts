import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-institucion',
  templateUrl: './all-institucion.component.html',
  styleUrls: ['./all-institucion.component.css']
})
export class AllInstitucionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
