import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-usuario',
  templateUrl: './detail-usuario.component.html',
  styleUrls: ['./detail-usuario.component.css']
})
export class DetailUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
