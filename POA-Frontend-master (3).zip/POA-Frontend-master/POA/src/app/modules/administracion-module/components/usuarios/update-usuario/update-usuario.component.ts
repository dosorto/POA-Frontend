import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-usuario',
  templateUrl: './update-usuario.component.html',
  styleUrls: ['./update-usuario.component.css']
})
export class UpdateUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
