import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-empleado',
  templateUrl: './create-empleado.component.html',
  styleUrls: ['./create-empleado.component.css']
})
export class CreateEmpleadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
