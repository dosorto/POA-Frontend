import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-rol',
  templateUrl: './create-rol.component.html',
  styleUrls: ['./create-rol.component.css']
})
export class CreateRolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
