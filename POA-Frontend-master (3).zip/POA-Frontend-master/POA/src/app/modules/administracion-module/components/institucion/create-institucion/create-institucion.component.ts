import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-institucion',
  templateUrl: './create-institucion.component.html',
  styleUrls: ['./create-institucion.component.css']
})
export class CreateInstitucionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
