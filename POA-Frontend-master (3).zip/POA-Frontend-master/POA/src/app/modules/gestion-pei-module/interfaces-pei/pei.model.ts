export interface Pei {
        id:          number;
        name:        string;
        initialYear: string;
        finalYear:   string;
        isActive:    boolean;
        isDelete:    boolean;
        createdAt:   Date;
        updatedAt:   Date;
        idInstitucion: number;
    }
