import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-area-component',
  templateUrl: './delete-area-component.component.html',
  styleUrls: ['./delete-area-component.component.css']
})
export class DeleteAreaComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
