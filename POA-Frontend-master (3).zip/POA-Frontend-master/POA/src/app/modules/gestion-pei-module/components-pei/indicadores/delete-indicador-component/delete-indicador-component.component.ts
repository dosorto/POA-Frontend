import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-indicador-component',
  templateUrl: './delete-indicador-component.component.html',
  styleUrls: ['./delete-indicador-component.component.css']
})
export class DeleteIndicadorComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
