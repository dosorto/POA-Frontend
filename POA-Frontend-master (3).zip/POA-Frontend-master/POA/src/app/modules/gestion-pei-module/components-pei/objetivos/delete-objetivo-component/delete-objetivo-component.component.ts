import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-objetivo-component',
  templateUrl: './delete-objetivo-component.component.html',
  styleUrls: ['./delete-objetivo-component.component.css']
})
export class DeleteObjetivoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
