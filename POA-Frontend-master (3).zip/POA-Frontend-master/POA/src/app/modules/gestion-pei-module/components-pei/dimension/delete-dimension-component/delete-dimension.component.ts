import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-dimension',
  templateUrl: './delete-dimension.component.html',
  styleUrls: ['./delete-dimension.component.css']
})
export class DeleteDimensionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
