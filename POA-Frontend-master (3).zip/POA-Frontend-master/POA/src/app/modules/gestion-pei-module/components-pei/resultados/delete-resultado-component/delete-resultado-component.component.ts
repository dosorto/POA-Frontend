import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-resultado-component',
  templateUrl: './delete-resultado-component.component.html',
  styleUrls: ['./delete-resultado-component.component.css']
})
export class DeleteResultadoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
