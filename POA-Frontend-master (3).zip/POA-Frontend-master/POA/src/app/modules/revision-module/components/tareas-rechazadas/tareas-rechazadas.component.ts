import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tareas-rechazadas',
  templateUrl: './tareas-rechazadas.component.html',
  styleUrls: ['./tareas-rechazadas.component.css']
})
export class TareasRechazadasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
