import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tareas-aprobadas',
  templateUrl: './tareas-aprobadas.component.html',
  styleUrls: ['./tareas-aprobadas.component.css']
})
export class TareasAprobadasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
