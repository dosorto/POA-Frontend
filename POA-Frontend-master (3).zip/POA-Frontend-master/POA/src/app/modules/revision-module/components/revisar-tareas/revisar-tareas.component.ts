import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revisar-tareas',
  templateUrl: './revisar-tareas.component.html',
  styleUrls: ['./revisar-tareas.component.css']
})
export class RevisarTareasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
