import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tareas-revisadas',
  templateUrl: './tareas-revisadas.component.html',
  styleUrls: ['./tareas-revisadas.component.css']
})
export class TareasRevisadasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
