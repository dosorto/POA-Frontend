export interface Grupogasto {
    id:             number;
    nombre:         string;
    identificador: number;
    isDelete:       boolean;
    createdAt:      Date;
    updatedAt:      Date;
}