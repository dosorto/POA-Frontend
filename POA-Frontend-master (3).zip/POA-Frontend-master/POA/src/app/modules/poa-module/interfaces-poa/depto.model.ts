export interface Depto {
    id:          number;
    name:        string;
    descripcion: string;
    isDelete:    boolean;
    createdAt:   Date;
    updatedAt:   Date;
}