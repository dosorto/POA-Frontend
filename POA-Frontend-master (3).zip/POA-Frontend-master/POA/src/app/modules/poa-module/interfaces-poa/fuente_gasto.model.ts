export interface Fuente {
    id:            number;
    nombre:        string;
    identificador: string;
    isDelete:      boolean;
    createdAt:     Date;
    updatedAt:     Date;
    idgrupo:      number;
}