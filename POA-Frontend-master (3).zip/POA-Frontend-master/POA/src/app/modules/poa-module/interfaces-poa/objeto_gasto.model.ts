export interface ObjetoGasto {
    id:            number;
    nombre:        string;
    identificador: string;
    isDelete:      boolean;
    createdAt:     Date;
    updatedAt:     Date;
    idgrupo:       number;
}