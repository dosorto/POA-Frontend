export interface Unidadmedida {
    id:        number;
    nombre:    string;
    isDelete:  boolean;
    createdAt: Date;
    updatedAt: Date;
}