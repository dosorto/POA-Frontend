export interface TareasH {
    id:        number;
    nombre:    string;
    idobjeto:  number;
    objeto:    string;
    idgrupo:   number;
    grupo:     string;
    isDelete:  boolean;
    createdAt: Date;
    updatedAt: Date;
}
