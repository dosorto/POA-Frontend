import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-presupuesto-poa',
  templateUrl: './presupuesto-poa.component.html',
  styleUrls: ['./presupuesto-poa.component.css']
})
export class PresupuestoPoaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
