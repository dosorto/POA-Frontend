import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-responsable',
  templateUrl: './all-responsable.component.html',
  styleUrls: ['./all-responsable.component.css']
})
export class AllResponsableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
