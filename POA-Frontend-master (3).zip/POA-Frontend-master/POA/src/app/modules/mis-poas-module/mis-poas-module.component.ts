import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mis-poas-module',
  templateUrl: './mis-poas-module.component.html',
  styleUrls: ['./mis-poas-module.component.css']
})
export class MisPoasModuleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
