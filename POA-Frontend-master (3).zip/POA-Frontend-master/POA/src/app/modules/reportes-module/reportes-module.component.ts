import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportes-module',
  templateUrl: './reportes-module.component.html',
  styleUrls: ['./reportes-module.component.css']
})
export class ReportesModuleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
