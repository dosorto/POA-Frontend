export const navbarData = [
    {
        routeLink:'home',
        icon: 'fal fa-home',
        label: 'Menú Principal'
    }
];